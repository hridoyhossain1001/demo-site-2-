<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
	exit;
}

delete_option('buykorigw_settings');
delete_option('buykorigw_custom_events');

delete_transient('buykorigw_update_info');

$timestamp = wp_next_scheduled('buykorigw_retry_confirm_cron');
if ($timestamp) {
	wp_unschedule_event($timestamp, 'buykorigw_retry_confirm_cron');
}
wp_clear_scheduled_hook('buykorigw_sync_purchase');

if (function_exists('as_unschedule_all_actions')) {
	as_unschedule_all_actions('buykorigw_retry_confirm');
	as_unschedule_all_actions('buykorigw_retry_cancel');
	as_unschedule_all_actions('buykorigw_sync_purchase');
}
